# Premium Weather Dashboard

A responsive, single-page premium weather application built with HTML, CSS (Glassmorphism), and Vanilla JavaScript. This project demonstrates modern asynchronous JavaScript (`async`/`await`), fetching and parsing JSON data from a public REST API, and dynamic DOM manipulation with fluid animations.

## Features

- **Real-Time Data Fetching:** Retrieves live temperature, humidity, and wind speed using the modern Fetch API.
- **Glassmorphism UI:** Premium, modern frosted glass effect with deep gradient background.
- **Animations:** Custom CSS loading spinners and smooth slide-up animations.
- **Two-Step API Integration:** Connects to the Open-Meteo Geocoding API to resolve city names into coordinates, then fetches weather metrics using those coordinates.
- **Comprehensive Error Handling:** Gracefully handles failed network requests and invalid city inputs.
- **Keyboard Accessibility:** Supports pressing the "Enter" key to trigger the search function.

## Technologies Used

- **HTML5:** Semantic structure with inline SVGs for premium icons
- **CSS3:** Flexbox layout, responsive design, Glassmorphism, CSS keyframe animations
- **Vanilla JavaScript (ES6+):** Async/await, Arrow functions, Destructuring, and DOM manipulation
- **REST APIs:** [Open-Meteo API](https://open-meteo.com/) (No API key required)

## Getting Started

Since this is a vanilla front-end project with no build tools or dependencies, setup is instantaneous.

### Execution
1. Extract this zip file to your local machine.
2. Open the `index.html` file directly in your web browser. 
   *(Alternatively, if using VS Code, right-click `index.html` and select **Open with Live Server** for automatic reloading).*

## Usage

1. Launch the application in your browser.
2. Enter the name of a city (e.g., "London", "New York", "Tokyo") into the input field.
3. Click the **Search** button or press the **Enter** key.
4. View the accurate, live weather metrics displayed on the beautiful premium dashboard.
